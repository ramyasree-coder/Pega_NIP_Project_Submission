# Movie Ticket Booking Demo

A demo-style web application based on the Pega Movie Ticket Booking requirements US-001 through US-010.

## Included
- Movie ticket request form
- Movie, show time, theatre and attendee details
- Seat selection and availability-style UI
- Booking cost calculation
- Booking confirmation number generation
- Booking summary
- US-001 to US-010 coverage panel

## Deploy
This is a static HTML/CSS/JavaScript application. Upload the repository to GitHub and import it into Vercel, or use Vercel Drop.

This is a front-end demonstration and is not connected to the Pega Academy backend.
